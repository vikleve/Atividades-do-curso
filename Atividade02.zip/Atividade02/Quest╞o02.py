peso = float(input("Digite o seu peso em kg: "))
altura = float(input("Digite a sua altura em metros: "))
imc = peso / (altura ** 2)
if imc < 18.5:
    print(f'Seu IMC é {imc:.2f}, você está abaixo do peso ideal.')
elif 18.5 <= imc < 25:
    print(f'Seu IMC é {imc:.2f}, você está com o peso ideal.')
elif 25 <= imc < 30:
    print(f'Seu IMC é {imc:.2f}, você está com sobrepeso.')
else:
    print(f'Seu IMC é {imc:.2f}, você está com obesidade.')