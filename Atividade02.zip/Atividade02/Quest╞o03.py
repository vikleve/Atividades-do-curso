#Analisando triângulos
lado1 = float(input("Digite o valor do primeiro reta do triângulo: "))
lado2 = float(input("Digite o valor do segundo reta do triângulo: "))
lado3 = float(input("Digite o valor do terceiro reta do triângulo: "))
if (lado1 < lado2 + lado3) and (lado2 < lado1 + lado3) and (lado3 < lado1 + lado2):
    if lado1 == lado2 == lado3:
        print("Os lados formam um triângulo.")
        print("O triângulo é equilátero.")
    elif lado1 == lado2 or lado1 == lado3 or lado2 == lado3:
        print("Os lados formam um triângulo.")
        print("O triângulo é isósceles.")
    else:
        print("Os lados formam um triângulo.")
        print("O triângulo é escaleno.")
else:
    print("Os lados não formam um triângulo.")