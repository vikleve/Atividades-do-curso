velocidade = float(input("Digite a velocidade do carro em km/h: "))
if velocidade > 80:
    multa = (velocidade - 80) * 7
    print(f'Sua velocidade esta acima do limite de velocidade, sua multa é de: {multa:.2f}')
else:
    print('Vocë esta dentro do limite de velocidade, Tenha uma boa viagem!')