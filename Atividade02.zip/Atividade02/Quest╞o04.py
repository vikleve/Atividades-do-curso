#Login de usuario
usuario = "admin"
senha = 'python123'
#Solicitar ao usuário que insira o nome de usuário e senha
input_usuario = input("Digite o nome de usuário: ")
input_senha = input("Digite a senha: ")
if input_usuario == usuario and input_senha == senha:
   print("acesso concedido")
elif input_usuario != usuario and input_senha == senha:
   print("Usuário não encontrado")
elif input_usuario == usuario and input_senha != senha:
   print("Senha incorreta")