#Conversão de moedas
real = float(input("Digite o valor em reais: "))
escolha = int(input("Digite 1 para converter para dólar, 2 para euro ou 3 para bitcoin: "))
if escolha == 1: 
    dolar = real / 5.0
    print(f'O valor em dólares é: {dolar:.2f}')
elif escolha == 2:
    euro = real / 5.5
    print(f'O valor em euros é: {euro:.2f}')
elif escolha == 3:
    bitcoin = real / 300000.0
    print(f'O valor em bitcoins é: {bitcoin:.4f}')
else:
    print("Opção inválida. Por favor, escolha 1, 2 ou 3.")